package aw222zr_assignment1.ferry;

public class Passenger extends FerryClass {

	protected void passengerTalksGood() {
		System.out.println("\nBipolar passenger says: 'What a nice ferry'.");
	}

	protected void passengerTalksBad() {
		System.out.println("\nBipolar passenger says: 'What an awful ferry'.");
	}

}
