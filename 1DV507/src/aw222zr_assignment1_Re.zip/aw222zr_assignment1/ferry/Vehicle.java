package aw222zr_assignment1.ferry;

public class Vehicle {

	protected int numberOfVehicles;
	protected int passengersInVehicle;

	public int getPassengers() {
		return passengersInVehicle;
	}

}
