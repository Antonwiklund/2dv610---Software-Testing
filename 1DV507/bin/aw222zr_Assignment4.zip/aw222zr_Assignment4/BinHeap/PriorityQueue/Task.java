package aw222zr_Assignment4.BinHeap.PriorityQueue;

public interface Task {

	public String toString();

	public void setTask(String taskInput);

	public String getTask();

	public void setPriority(int priorityInput);

	public int getPriority();

}
